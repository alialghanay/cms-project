package cms.sendMail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendMailApplicationTests {

	@Test
	void contextLoads() {
	}

}
